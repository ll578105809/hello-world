#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "thread_pool.h"


threadPool * cp_thread;
struct copy_file_path
{
	char file1[256];
	char file2[256];
};
void* copy_file(void *arg)
{
	struct copy_file_path *p = arg;
	char *file1 = p->file1;
	char *file2 = p->file2;
	int r;
	unsigned char buf[256];
	int fd1 = open(file1,O_RDONLY);
	if(fd1 == -1)
	{
		perror("open file1 error");
		exit(0);
	}
	int fd2 = open(file2,O_CREAT|O_WRONLY|O_TRUNC,0664);
	if(fd2 == -1)
	{
		perror("open file1 error");
		exit(0);
	}
	while(r = read(fd1,buf,256))
	{
		write(fd2,buf,r);
	}
	close(fd1);
	close(fd2);
	return NULL;
}

void *pthread(void * arg)
{
	//pthread_detach(pthread_self());//�������߳�����Ϊ��������
	struct copy_file_path *p = arg;
	copy_file(p);
}

int copy_dir(const char *path1,const char *path2)
{
	int r =  mkdir(path2,0777);//Ŀ¼һ��Ҫ�п�ִ��Ȩ��
	char path_tmp[256]={0};
	strcpy(path_tmp,path1);
	if(path_tmp[strlen(path_tmp)-1] == '/')
	{
		path_tmp[strlen(path_tmp)-1] = '\0';
	}
	
	int total_size = 0;
	DIR *dirp = opendir(path1);
	if(dirp == NULL)
	{
		puts(path1);
		perror("opendir path error");
		exit(0);
	}
	struct dirent *dt = NULL;
	while(dt=readdir(dirp))
	{
		struct stat st;
		char filename1[256];
		sprintf(filename1,"%s/%s",path_tmp,dt->d_name);//�ϳ�·��
		char filename2[256];
		sprintf(filename2,"%s/%s",path2,dt->d_name);//�ϳ�·��
		int r = lstat(filename1,&st);//����Ƿ��������ļ��������ӵ��ļ������ڣ���stat�����
		if(r == -1)
		{
			puts(filename1);
			perror("stat error");
			exit(0);
		}
		
		if(S_ISREG(st.st_mode))//��ͨ�ļ�
		{
			puts(filename1);
			struct copy_file_path *p = malloc(sizeof(*p));
			strcpy(p->file1,filename1);
			strcpy(p->file2,filename2);
			
			add_task(cp_thread,pthread,(void*)p);
			
		}
		else if(S_ISDIR(st.st_mode))//Ŀ¼
		{
			if(strcmp(dt->d_name,".")!=0 && strcmp(dt->d_name,"..")!=0)//Ҫ�ܿ�. .. ��������Ŀ¼
			{
				copy_dir(filename1,filename2);//�����Ŀ¼���ݹ����
			}
		}	
	}
	
	closedir(dirp);//�ر�Ŀ¼
	return total_size;
}

int main(int argc,const char **argv)
{
	if(argc != 3)
	{
		printf("argment error\n");
		return -1;
	}
	cp_thread=thread_pool_init(16); //初始化
	start_thread_pool(cp_thread);//创建
	copy_dir(argv[1],argv[2]);
	cp_thread->shutdown=1;
	
	finish_thread_pool(cp_thread);
	thread_pool_destroy(cp_thread);
	return 0;
}
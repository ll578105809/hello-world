#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include "thread_pool.h"

threadPool * thread_pool_init(int thread_Num)//初始化线程池，只创建头结点
{
	threadPool *list=malloc(sizeof(*list));	
	list->first=NULL;
	list->last=NULL;
	list->NodeNum=0;
	list->thread_Num=thread_Num;
	list->shutdown=1;
	
	list->tid=malloc(sizeof(long unsigned int)*list->thread_Num);
	
	list->mutex=malloc(sizeof(*list->mutex));
	list->cond=malloc(sizeof(*list->cond));
	if(pthread_mutex_init(list->mutex,NULL)==-1)
	{
		perror("init mutex error");
		return NULL;
	}
	if(pthread_cond_init(list->cond,NULL)==-1)
	{
		perror("init cond error");
		return NULL;
	}
	return list;
		
}


int add_task(threadPool *list,void *(*fun)(void *),void *arg)//任务入任务链表
{
	if(list==NULL)
	{
		printf("add_task error:该线程池未创建\n");
		return -1;
	}
	//pthread_mutex_lock(list->mutex);//互斥插入链表
	struct task_node *pnew=malloc(sizeof(*pnew));
	pnew->fun=fun;
	pnew->arg=arg;
	pnew->next=NULL;
	list->NodeNum++;
	
	//无中生有
	if(list->first==NULL)
	{
		list->first=pnew;
		list->last=pnew;	
	}
	else //由少到多
	{
		list->last->next=pnew;
		list->last=pnew;
	}
	
	
	//pthread_mutex_unlock(list->mutex);
	if(list->NodeNum>0)
	{
		pthread_mutex_lock(list->mutex);//P操作
		pthread_cond_signal(list->cond);//同步,来任务唤醒
		pthread_mutex_unlock(list->mutex);
	}
	
	printf("线程池任务添加成功\n");
	
	
	
	return 0;
}
struct task_node * out_task(threadPool *list)
{
	if(list==NULL)
	{
		printf("out_task error:该线程池未创建\n");
		return NULL;
	}
	struct task_node *p_del=malloc(sizeof(*p_del));
	if(list->NodeNum==1)
	{
		list->NodeNum--;
	
		p_del->fun=list->first->fun;
		p_del->arg=list->first->arg;
		p_del->next=NULL;
		
		free(list->first);
		list->first=NULL;
		list->last=NULL;
		
	}
	else if(list->NodeNum==0)
	{
		printf("out_task error:任务链表为空\n");
		return NULL;
	}
	else
	{
		list->NodeNum--;
		p_del->fun=list->first->fun;
		p_del->arg=list->first->arg;
		p_del->next=NULL;

		struct task_node *p_temp=list->first;
		list->first=p_temp->next;
		p_temp->next=NULL;
		
		free(p_temp);
	}
	printf("删除首结点成功\n");
	return p_del;
}
void *active_thread(void *arg)
{
	threadPool *list = (threadPool *)arg;
	if(list==NULL)
	{
		printf("active_thread error:该线程池未创建\n");
		return NULL;
	}
	while(1)
	{
		/*取任务*/
		pthread_mutex_lock(list->mutex);//P操作
		
		
		while(list->shutdown==0 && list->NodeNum == 0)
		{
			printf("no\n");
			pthread_cond_wait(list->cond,list->mutex);//同步,没任务沉睡
		}
		if(list->shutdown==1 && list->NodeNum==0)//任务做完了，结束线程池
		{
			printf("yes\n");
			pthread_mutex_unlock(list->mutex);//V
			pthread_cond_broadcast(list->cond);
			pthread_exit(NULL);
		}
		
		printf("hehe %d\n",list->NodeNum);
		struct task_node *p=out_task(list);

		pthread_mutex_unlock(list->mutex);//V操作
		
		


		
		p->fun(p->arg);//执行任务
	//	free(p->arg);
		free(p);
	}
}

int start_thread_pool(threadPool *list)//创建活动线程
{
	if(list==NULL)
	{
		printf("start_thread_pool error:该线程池未创建\n");
		return -1;
	}
	list->shutdown=0;
	int n=0;
	int r;
	while(n < list->thread_Num)
	{
		if(pthread_create(list->tid+n,NULL,active_thread,(void*)list)!=0)
		{
			perror("线程创建失败\n");
			return -1;
		}
		printf("Num is %d\n",n);
		n++;
	}
	printf("活动线程创建成功\n");	
	return 0;
}
int finish_thread_pool(threadPool *list)//等待链表为空，每个活动线程的任务做完
{
	if(list==NULL)
	{
		printf("finish_thread_pool error:该线程池未创建\n");
		return -1;
	}
	int n;
	int r;
	for(n=0;n<list->thread_Num;n++)
	{
		if((r=pthread_join(list->tid[n],NULL))!=0)
		{

			printf("r is %d\n",r);
		}
		
		printf("num is %d flag is %d\n",list->NodeNum,list->shutdown);
		/*
		printf("thread_Num is %d  %d %lu\n",list->thread_Num,n,*(list->tid+n));
		
		printf("size is %d\n",sizeof(*list->tid)*list->thread_Num);
		*/
		//sleep(5);
	}

	printf("任务已完成\n");
	return 1;
}
int thread_pool_destroy(threadPool *list)//销毁一个已经结束的线程池
{
	if(list==NULL)
	{
		printf("thread_pool_destroy error:该线程池未创建\n");
		return -1;
	}
	if(list->shutdown==1)
	{
		free(list->mutex);
		free(list->cond);
		free(list->tid);
		free(list);
	}
	else
	{
		printf("线程池正在运行，无法删除\n");
		return -1;
	}
	
}


